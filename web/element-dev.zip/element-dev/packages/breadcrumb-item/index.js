import ElBreadcrumbItem from '../breadcrumb/src/breadcrumb-item';

/* istanbul ignore next */
ElBreadcrumbItem.install = function(Vue) {
  Vue.component(ElBreadcrumbItem.name, ElBreadcrumbItem);
};

export default ElBreadcrumbItem;
